import React from "react";
import logo from "../assets/logo.png";
import { Navigate, useNavigate } from "react-router-dom";
import Main from "../Main/Main";

const Write = () => {

    const navigate = useNavigate()

    return (
        <div className="qnaContainer">
            <Main />
            <div className="qnaInputContainer">
                <input
                    type="text"
                    placeholder="이름을 입력해주세요"
                    className="qnaInput"
                />
                <input
                    type="text"
                    placeholder="제목을 입력해주세요"
                    className="qnaInput"
                />
                <textarea
                    placeholder="내용을 입력해주세요"
                    className="qnaInputtext"
                />
                <button className="qnaButton" onClick={() => navigate("/board")}>보내기</button>
                <button className="qnaButton" onClick={() => navigate('/board')}>돌아가기</button>
            </div>
        </div>

    );
}
export default Write