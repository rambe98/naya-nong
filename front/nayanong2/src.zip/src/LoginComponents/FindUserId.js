import React, { useState, useEffect } from 'react'
import logo from '../assets/logo.png'
import axios from 'axios'
import { useParams } from 'react-router-dom'

const FindUserId = () => {
    const [userName, setUserName] = useState('')
    const [userPnum, setUserPnum] = useState('')
    const [verificationCode, setVerificationCode] = useState('');
    const [message, setMessage] = useState('');
    const [isCodeSent, setIsCodeSent] = useState(false);

    //인증번호 전송
    const sendVerificationCode = async () => {
        try {
            const response = await fetch('/api/send-verification-code', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userPnum }),
            })

            const data = await response.json()
            if (data.success) {
                setMessage('인증번호가 전송되었습니다.')
                setIsCodeSent(true)
            } else {
                setMessage('전화번호를 확인해주세요.')
            }
        } catch (error) {
            setMessage('오류입니다. 다시 시도해 주세요.')
        }
    }

    //아이디 찾기
    const findUserId = async () => {
        try {
            const response = await fetch('/api/find-id', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userName, userPnum, verificationCode }),
            })
            const data = await response.json()
            if (data.success) {
                setMessage(`아이디: ${data.id}`)
            } else {
                setMessage("인증번호가 일치하지 않거나 사용자 정보를 찾을 수 없습니다.")
            }
        } catch (error) {
            setMessage('오류입니다. 다시 시도해 주세요.')
        }
    }
    return (
        <div>
            <h1>아이디 찾기</h1>
            <div>
                <label>이름 : </label>
                <input type='text' value={userName} onChange={(e) => setUserName(e.target.value)} placeholder='이름' />
            </div>
            <div>
                <label>휴대전화 : </label>
                <input type='text' value={userPnum} onChange={(e) => setUserPnum(e.target.value)} placeholder='전화번호' />
            </div>
            {!isCodeSent ? (
                <button onClick={sendVerificationCode}>인증번호 받기</button>
            ) : (
                <div>
                    <label>인증번호 : </label>
                    <input type='text' value={verificationCode} onChange={(e) => setVerificationCode(e.target.value)} placeholder='인증번호호 입력' />
                    <button onClick={findUserId}>아이디 찾기</button>
                </div>
            )}
            {message && <p>{message}</p>}
        </div>
    )
}
export default FindUserId